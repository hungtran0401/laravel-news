$('div .alert').delay(3000).slideUp();

function xacnhanxoa(msg){
	if(window.confirm(msg)){
		return true;
	}
	return false;
}